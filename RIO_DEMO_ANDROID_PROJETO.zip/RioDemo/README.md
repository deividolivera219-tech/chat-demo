# Rio Demo (Android)

Projeto Android independente para testar a interface do Rio sem Termux e sem tocar na instalação atual.

## O que esta demonstração faz
- Abre como aplicativo Android com nome **Rio Demo**.
- Interface de chat offline.
- Guarda o histórico usando armazenamento local do WebView.
- Não usa internet, Termux, servidor Python ou banco do projeto original.

## Limitação importante
Esta primeira demonstração **não contém um modelo de IA**. As respostas são regras locais simples para testar a experiência, não são respostas geradas por Qwen. A integração de um modelo local (por exemplo, via runtime Android/llama.cpp e arquivo GGUF compatível) é uma etapa posterior e exige escolher um modelo que caiba na memória e no armazenamento do aparelho.

## Como gerar o APK
Abra esta pasta no Android Studio, aguarde a sincronização do Gradle e use **Build > Build Bundle(s) / APK(s) > Build APK(s)**. O APK de debug será criado em `app/build/outputs/apk/debug/app-debug.apk`.

Requisitos: Android Studio com Android SDK 35, JDK 17 e conexão inicial para baixar as dependências do Gradle. `applicationId`: `br.com.riodemo.app` (separado do projeto original).
